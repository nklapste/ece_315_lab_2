/*
 * point.h
 *
 *  Created on: Sep 22, 2016
 *      Author: nem
 */

#ifndef POINT_H_
#define POINT_H_

typedef struct struct_point {
	unsigned char col;
	unsigned char row;
} point;


#endif /* POINT_H_ */
